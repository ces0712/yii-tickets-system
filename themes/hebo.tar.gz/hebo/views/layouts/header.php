<div class="container">
<div class="row-fluid">

  <div class="span6">
		<a href="" class="logo"></a>
  </div><!--/.span6 -->
  
  <div class="span6">
    <!-- <div class="social-icons pull-right clearfix">
        <div class="" style="text-align:right;"><img src="<?php echo $baseUrl;?>/img/icons/social/facebook.png"  alt="Facebook" /> <img src="<?php echo $baseUrl;?>/img/icons/social/twitter.png"  alt="Twitter" /> <img src="<?php echo $baseUrl;?>/img/icons/social/linkedin.png"  alt="LinkedIn" /> <img src="<?php echo $baseUrl;?>/img/icons/social/google.png"  alt="Google+" /> <img src="<?php echo $baseUrl;?>/img/icons/social/rss.png"  alt="RSS" /></div>
        <div class="header-text" style="">TOLL FREE: (123) 456 7890</div>
    </div>/.social-icons -->
   
  </div><!--/.span6 -->
</div><!--/.row-fluid header -->
</div>
