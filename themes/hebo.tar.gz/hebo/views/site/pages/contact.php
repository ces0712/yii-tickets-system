<div class="container shout-box">
    <div class="shout-text">
      <h1>Greatest website ever</h1>
      <p>We work very hard to bring you the best website themes.<br> All our themes are responsive and look great on any device.</p>
    </div>
</div>
      
        <div class="row-fluid">
            <div class="span6">
            
            	<div class="row-fluid">
                    <div class="span6">
                        <h3>Address</h3>
                        <p>
                        20 Glenville Road<br />
                        Hatfeild<br />
                        Harare<br />
                        ZIMBABWE
                        </p>
                    </div>
                    <div class="span6">
                        <h3>Contact details</h3>
                        <p>
                        P: +123 (456) 7890<br />
                        F: +123 (456) 7890<br />
                        E: info@example.com<br />
                        W: www.example.com
                        </p>
                    </div>
                </div>
                <br />
                <label>Full Name</label>
                <input class="span12" type="text" placeholder="Your full name">
                <label>Email Address</label>
                <input class="span12" type="text" placeholder="Your email address">
                <label>Message</label>
                <textarea rows="7" class="span12"  placeholder="Your message"></textarea>
                <p>
                  <button class="btn" type="button">Send</button>
                </p>
                
            </div>
            <div class="span6">
               
               <!-- start google map -->
               	<iframe width="450" height="450" frameborder="0" scrolling="no" marginheight="0" marginwidth="0" src="https://maps.google.com/maps?f=q&amp;source=s_q&amp;hl=en&amp;geocode=&amp;q=harare&amp;aq=&amp;sll=37.0625,-95.677068&amp;sspn=40.052282,86.572266&amp;ie=UTF8&amp;hq=&amp;hnear=Harare,+Zimbabwe&amp;t=m&amp;ll=-17.822814,31.054916&amp;spn=0.03677,0.038538&amp;z=14&amp;output=embed"></iframe><br /><small><a href="https://maps.google.com/maps?f=q&amp;source=embed&amp;hl=en&amp;geocode=&amp;q=harare&amp;aq=&amp;sll=37.0625,-95.677068&amp;sspn=40.052282,86.572266&amp;ie=UTF8&amp;hq=&amp;hnear=Harare,+Zimbabwe&amp;t=m&amp;ll=-17.822814,31.054916&amp;spn=0.03677,0.038538&amp;z=14" style="color:#0000FF;text-align:left">View Larger Map</a></small>
               <!-- end google map -->
            
                
            </div>
        </div>
    </div>